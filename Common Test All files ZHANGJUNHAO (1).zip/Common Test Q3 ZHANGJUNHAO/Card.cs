﻿class Card
{
    private string cardNumber;
    private string cardHolderName;
    public double totalPaid;

    public Card() { }

    public Card(string cardNumber, string cardHolderName)
    {
        this.cardNumber = cardNumber;
        this.cardHolderName = cardHolderName;
    }
}

class CreditCard : Card
{
    private int expiryMonth;
    private int expiryYear;
    private double creditLimit;
    private double rebate;

    public CreditCard() { }

    public CreditCard(string cardNumber, string cardHolderName, int expiryMonth, int expiryYear, double creditLimit)
        : base(cardNumber, cardHolderName)
    {
        this.expiryMonth = expiryMonth;
        this.expiryYear = expiryYear;
        this.creditLimit = creditLimit;
        this.rebate = 0;
    }

    public bool MakePayment(double amount)
    {
        if (!IsExpired() && amount <= creditLimit)
        {
            totalPaid += amount;
            rebate += amount * 0.015; 
            return true;
        }
        return false;
    }

    public bool IsExpired()
    {
        return false;
    }
}

class DebitCard : Card
{
    private int pin;

    public DebitCard() { }

    public DebitCard(string cardNumber, string cardHolderName, int pin)
        : base(cardNumber, cardHolderName)
    {
        this.pin = pin;
    }
}

