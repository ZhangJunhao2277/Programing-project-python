﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter Employee ID: ");
        string empID = Console.ReadLine();

        Console.Write("Enter the hours worked: ");
        int hoursWorked = int.Parse(Console.ReadLine());

        Employee employee = new Employee(empID, hoursWorked);
        double payment = employee.CalculatePay();

        Console.WriteLine($"Payment due to Employee #{employee.empID}: ${payment:F2}");
    }
}
