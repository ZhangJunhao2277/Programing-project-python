﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Employee
{
    public string empID;
    public int hours;
    public double rate;

    public Employee()
    {
        empID = "";
        hours = 0;
        rate = 7.50;
    }

    public Employee(string id, int hrs)
    {
        empID = id;
        hours = hrs;
        rate = 7.50;
    }
    public double CalculatePay()
    {
        double pay = hours * rate;
        if (hours >= 5)
        {
            pay += 10;
        }
        return pay;
    }


}
