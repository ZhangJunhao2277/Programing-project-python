﻿using System;
using System.Collections.Generic;

class Cohort
{
    private string title;
    private int enrolYear;
    private int maxEnrolment;
    private Queue<string> studentQueue;

    public Cohort()
    {
        studentQueue = new Queue<string>();
    }

    public Cohort(string title, int enrolYear, int maxEnrolment)
    {
        this.title = title;
        this.enrolYear = enrolYear;
        this.maxEnrolment = maxEnrolment;
        studentQueue = new Queue<string>();
    }

    public void EnrolStudent(string studentName)
    {
        if (studentQueue.Count < maxEnrolment)
        {
            studentQueue.Enqueue(studentName);
        }
        else
        {
            Console.WriteLine("Max number of students reached.");
        }
    }

    public override string ToString()
    {
        string cohortDetails = $"Course: {title}, Year: {enrolYear}, Max Students: {maxEnrolment}\n";
        cohortDetails += "Students enrolled:\n";
        foreach (string student in studentQueue)
        {
            cohortDetails += $"{student}\n";
        }
        return cohortDetails;
    }
}

