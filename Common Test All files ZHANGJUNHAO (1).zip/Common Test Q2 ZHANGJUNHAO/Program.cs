﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter the course title:");
        string courseTitle = Console.ReadLine();

        Console.WriteLine("Enter the enrolment year:");
        int enrolYear = int.Parse(Console.ReadLine());

        Console.WriteLine("Enter the max enrolment:");
        int maxEnrolment = int.Parse(Console.ReadLine());

        Cohort myCohort = new Cohort(courseTitle, enrolYear, maxEnrolment);
        Console.WriteLine($"The course {courseTitle} with max enrolment {maxEnrolment} students has been created.");

        for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Enter name {i + 1}:");
                string studentName = Console.ReadLine();
                myCohort.EnrolStudent(studentName);
            }

            Console.WriteLine($"Students enrolled in {enrolYear} {courseTitle} are:");
            Console.WriteLine(myCohort);
        }
    }

